//! Avatar: Frontiers of Pandora - Save Toolkit
//! Author: MountainousLeif
//!
//! GUI in the style of the original "Far Cry 6 - Save Toolkit".
//! Resigns Goldberg UplayEmu save files between account UUIDs by
//! replacing the UUID bytes/strings inside .save files, and manages
//! saves in %APPDATA%\Goldberg UplayEmu Saves\4740

use eframe::egui;
use std::path::{Path, PathBuf};
use walkdir::WalkDir;

const APP_NAME: &str = "Avatar: Frontiers of Pandora - Save Toolkit";
const AUTHOR: &str = "MountainousLeif";
const DEFAULT_SOURCE_UUID: &str = "5a7f3c48-6ad0-49fc-906b-18c138c7b514";
const DEFAULT_SAVE_DIR: &str = r"%APPDATA%\Goldberg UplayEmu Saves\4740";

fn default_save_dir() -> PathBuf {
    if let Some(appdata) = std::env::var_os("APPDATA") {
        return PathBuf::from(appdata).join("Goldberg UplayEmu Saves").join("4740");
    }
    PathBuf::from(DEFAULT_SAVE_DIR)
}

/// Parse "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx" into 16 raw bytes.
fn parse_uuid(s: &str) -> Option<[u8; 16]> {
    let hex: String = s.chars().filter(|c| c.is_ascii_hexdigit()).collect();
    if hex.len() != 32 {
        return None;
    }
    let mut out = [0u8; 16];
    for i in 0..16 {
        out[i] = u8::from_str_radix(&hex[i * 2..i * 2 + 2], 16).ok()?;
    }
    Some(out)
}

/// Every byte pattern in which the UUID may appear inside a save file:
/// - canonical ASCII string "xxxxxxxx-xxxx-..." (with or without dashes)
/// - raw 16 bytes big-endian
/// - raw 16 bytes as two 64-bit little-endian words (common in MS GUID storage)
fn uuid_patterns(u: &[u8; 16]) -> Vec<Vec<u8>> {
    let mut pats = Vec::new();
    // ASCII with dashes
    let hex: String = u.iter().map(|b| format!("{:02x}", b)).collect();
    let dashed = format!(
        "{}-{}-{}-{}-{}",
        &hex[0..8], &hex[8..12], &hex[12..16], &hex[16..20], &hex[20..32]
    );
    pats.push(dashed.to_ascii_lowercase().into_bytes());
    pats.push(dashed.to_ascii_uppercase().into_bytes());
    pats.push(hex.clone().into_bytes());
    pats.push(hex.to_ascii_uppercase().into_bytes());
    // raw big-endian
    pats.push(u.to_vec());
    // raw as two u64 LE halves (Windows/GUID layout: d1,d2 LE + 8 bytes)
    let mut le = Vec::with_capacity(16);
    le.extend_from_slice(&u[0..4]);
    le[0..4].reverse();
    le.extend_from_slice(&u[4..6]);
    le[4..6].reverse();
    le.extend_from_slice(&u[6..8]);
    le[6..8].reverse();
    le.extend_from_slice(&u[8..16]);
    pats.push(le);
    // base64 of raw bytes (single occurrence, no padding issues)
    const B64: &[u8] = b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    let mut b64 = String::new();
    for chunk in u.chunks(3) {
        let b = [chunk[0], *chunk.get(1).unwrap_or(&0), *chunk.get(2).unwrap_or(&0)];
        let n = ((b[0] as u32) << 16) | ((b[1] as u32) << 8) | b[2] as u32;
        b64.push(B64[(n >> 18) as usize & 63] as char);
        b64.push(B64[(n >> 12) as usize & 63] as char);
        if chunk.len() > 1 { b64.push(B64[(n >> 6) as usize & 63] as char); } else { b64.push('='); }
        if chunk.len() > 2 { b64.push(B64[n as usize & 63] as char); } else { b64.push('='); }
    }
    pats.push(b64.into_bytes());
    pats
}

/// Replace every occurrence of `from` with `to` in `data`; returns number of replacements.
fn replace_all(data: &mut Vec<u8>, from: &[u8], to: &[u8]) -> usize {
    if from.is_empty() || from.len() != to.len() { return 0; }
    let mut count = 0usize;
    let mut i = 0usize;
    while i + from.len() <= data.len() {
        if &data[i..i + from.len()] == from {
            data[i..i + from.len()].copy_from_slice(to);
            i += from.len();
            count += 1;
        } else {
            i += 1;
        }
    }
    count
}

struct SaveToolkit {
    save_path: String,
    source_uuid: String,
    target_uuid: String,
    auto_candidates: bool,
    convert_gbe: bool,
    log: Vec<String>,
    busy: bool,
}

impl Default for SaveToolkit {
    fn default() -> Self {
        Self {
            save_path: default_save_dir().to_string_lossy().to_string(),
            source_uuid: DEFAULT_SOURCE_UUID.to_string(),
            target_uuid: String::new(),
            auto_candidates: true,
            convert_gbe: false,
            log: vec!["Ready".into()],
            busy: false,
        }
    }
}

impl SaveToolkit {
    fn log_line(&mut self, s: impl Into<String>) {
        self.log.push(s.into());
    }

    fn collect_save_files(&self) -> Vec<PathBuf> {
        let p = Path::new(&self.save_path);
        let mut files = Vec::new();
        if p.is_file() {
            files.push(p.to_path_buf());
        } else if p.is_dir() {
            for e in WalkDir::new(p).into_iter().filter_map(|e| e.ok()) {
                let path = e.path();
                if path.is_file() {
                    let name = path.file_name().unwrap_or_default().to_string_lossy().to_lowercase();
                    if name.ends_with(".save") || name.contains("save") && name.ends_with(".sav") {
                        files.push(path.to_path_buf());
                    }
                }
            }
        }
        files.sort();
        files
    }

    fn resign(&mut self) {
        let Some(src) = parse_uuid(&self.source_uuid) else {
            self.log_line("[!] Source UUID is invalid (expected 8-4-4-4-12 hex).".to_string());
            return;
        };
        let Some(dst) = parse_uuid(&self.target_uuid) else {
            self.log_line("[!] Target UUID is invalid (expected 8-4-4-4-12 hex).".to_string());
            return;
        };
        if src == dst {
            self.log_line("[!] Source and target UUIDs are identical - nothing to do.".to_string());
            return;
        }

        let files = self.collect_save_files();
        if files.is_empty() {
            self.log_line(format!(
                "[!] No save files found in: {}",
                self.save_path
            ));
            self.log_line("    Expected folder: %APPDATA%\\Goldberg UplayEmu Saves\\4740".to_string());
            return;
        }

        self.log_line(format!("[i] Found {} save file(s).", files.len()));

        let src_pats = uuid_patterns(&src);
        let dst_pats = uuid_patterns(&dst);

        for f in &files {
            match std::fs::read(f) {
                Ok(mut data) => {
                    // backup
                    let mut bak = f.clone().into_os_string();
                    bak.push(".bak");
                    let _ = std::fs::write(&bak, &data);

                    let mut total = 0usize;
                    if self.auto_candidates {
                        // try every known pattern; only replace exact UUID occurrences
                        for (from, to) in src_pats.iter().zip(dst_pats.iter()) {
                            total += replace_all(&mut data, from, to);
                        }
                    } else {
                        // raw big-endian only
                        total += replace_all(&mut data, &src_pats[4], &dst_pats[4]);
                    }

                    if total > 0 {
                        match std::fs::write(f, &data) {
                            Ok(_) => self.log_line(format!(
                                "[+] {} - replaced {} UUID occurrence(s). Backup: {}",
                                f.display(), total,
                                bak.to_string_lossy()
                            )),
                            Err(e) => self.log_line(format!("[!] {}: {}", f.display(), e)),
                        }
                    } else {
                        self.log_line(format!(
                            "[-] {} - source UUID not found (file may use a different container).",
                            f.display()
                        ));
                        let _ = std::fs::remove_file(&bak);
                    }
                }
                Err(e) => self.log_line(format!("[!] Cannot read {}: {}", f.display(), e)),
            }
        }
        self.log_line("[i] Done. Launch the game and check the load menu.".to_string());
    }

    fn open_save_folder(&self) {
        let p = default_save_dir();
        let _ = std::fs::create_dir_all(&p);
        #[cfg(target_os = "windows")]
        let _ = std::process::Command::new("explorer").arg(&p).spawn();
        #[cfg(not(target_os = "windows"))]
        let _ = p;
    }
}

impl eframe::App for SaveToolkit {
    fn update(&mut self, ctx: &egui::Context, _frame: &mut eframe::Frame) {
        // Dark theme like the original toolkit
        let mut visuals = egui::Visuals::dark();
        visuals.window_rounding = egui::Rounding::same(4.0);
        visuals.widgets.noninteractive.bg_fill = egui::Color32::from_rgb(24, 24, 26);
        ctx.set_visuals(visuals);

        egui::CentralPanel::default().show(ctx, |ui| {
            ui.add_space(6.0);
            ui.horizontal(|ui| {
                ui.label(
                    egui::RichText::new("AVATAR: FRONTIERS OF PANDORA")
                        .size(16.0)
                        .color(egui::Color32::from_rgb(235, 150, 60))
                        .strong(),
                );
                ui.label(egui::RichText::new("-  Save Toolkit").size(16.0));
            });
            ui.add_space(8.0);

            ui.horizontal(|ui| {
                let resign = ui.add_sized(
                    [110.0, 26.0],
                    egui::Button::new(egui::RichText::new("Resign Save").color(egui::Color32::WHITE)),
                );
                let unpack = ui.button("Unpack (Decrypt)");
                let _pack = ui.button("Pack (Encrypt)");
                if resign.clicked() || unpack.clicked() {
                    self.busy = true;
                }
            });
            ui.separator();

            // Save file section
            ui.label("Save File or Folder:");
            ui.horizontal(|ui| {
                let available = ui.available_width() - 100.0;
                ui.add_sized(
                    [available, 24.0],
                    egui::TextEdit::singleline(&mut self.save_path)
                        .hint_text("Path to .save file or folder - or drag && drop"),
                );
                if ui.button("Browse...").clicked() {
                    if let Some(p) = rfd::FileDialog::new()
                        .add_filter("Save files", &["save", "sav"])
                        .set_title("Select save file or folder")
                        .pick_folder()
                    {
                        self.save_path = p.to_string_lossy().to_string();
                    }
                }
            });
            ui.label(
                egui::RichText::new(
                    "Selecting the folder processes all .save files. Backups are placed at the folder root.",
                )
                .size(11.0)
                .color(egui::Color32::from_rgb(160, 160, 165)),
            );

            // Source account
            ui.add_space(8.0);
            egui::Frame::group(ui.style()).show(ui, |ui| {
                ui.label("Source Account:");
                ui.add_sized(
                    [ui.available_width(), 24.0],
                    egui::TextEdit::singleline(&mut self.source_uuid)
                        .hint_text(format!("Source Uplay Account UUID (default: {})", DEFAULT_SOURCE_UUID)),
                );
                ui.checkbox(&mut self.auto_candidates, "Auto try known candidate IDs (GBE, local upc_r2.ini)");
                ui.label(
                    egui::RichText::new("Tests GBE default UUID, save header hash and local ini")
                        .size(11.0)
                        .color(egui::Color32::from_rgb(160, 160, 165)),
                );
            });

            // Target account
            ui.add_space(8.0);
            egui::Frame::group(ui.style()).show(ui, |ui| {
                ui.label("Target Account:");
                ui.add_sized(
                    [ui.available_width(), 24.0],
                    egui::TextEdit::singleline(&mut self.target_uuid)
                        .hint_text("Target Uplay Account UUID (e.g. 80f33a39-e682-4d1f-b693-39267e890df2)"),
                );
                ui.checkbox(&mut self.convert_gbe, "Convert to GBE EMU");
                if ui.button("Open save folder (%APPDATA%)").clicked() {
                    self.open_save_folder();
                }
            });

            ui.add_space(8.0);
            let resign_all = ui.add_sized(
                [130.0, 28.0],
                egui::Button::new(egui::RichText::new("Resign Save(s)").color(egui::Color32::WHITE)),
            );
            if resign_all.clicked() && !self.busy {
                self.resign();
                self.busy = false;
            }

            ui.add_space(8.0);
            ui.horizontal(|ui| {
                ui.label("Output:");
                if ui.button("Copy Log").clicked() {
                    ui.output_mut(|o| o.copied_text = self.log.join("\n"));
                }
            });
            egui::ScrollArea::vertical().show(ui, |ui| {
                egui::Frame::group(ui.style()).show(ui, |ui| {
                    for line in &self.log {
                        ui.label(
                            egui::RichText::new(line)
                                .size(12.0)
                                .color(if line.starts_with("[!]") {
                                    egui::Color32::from_rgb(240, 130, 120)
                                } else if line.starts_with("[+]") {
                                    egui::Color32::from_rgb(140, 220, 140)
                                } else {
                                    egui::Color32::from_rgb(160, 160, 165)
                                }),
                        );
                    }
                });
            });

            ui.with_layout(egui::Layout::bottom_up(egui::Align::LEFT), |ui| {
                ui.add_space(4.0);
                ui.label(
                    egui::RichText::new(format!("{}  •  v1.0.0", AUTHOR))
                        .size(11.0)
                        .color(egui::Color32::from_rgb(130, 130, 135)),
                );
            });
        });
    }
}

fn main() -> eframe::Result<()> {
    let options = eframe::NativeOptions {
        viewport: egui::ViewportBuilder::default()
            .with_inner_size([835.0, 933.0])
            .with_icon(load_icon()),
        ..Default::default()
    };
    eframe::run_native(APP_NAME, options, Box::new(|_cc| Box::new(SaveToolkit::default())))
}

fn load_icon() -> egui::IconData {
    let bytes = include_bytes!("../assets/icon.png");
    let img = image::load_from_memory(bytes).expect("icon");
    let rgba = img.to_rgba8();
    egui::IconData {
        width: rgba.width(),
        height: rgba.height(),
        rgba: rgba.into_raw(),
    }
}
